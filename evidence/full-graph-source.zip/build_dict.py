from pathlib import Path
import argparse
import collections
from contextlib import closing
import json
import sqlite3
import struct
from array import array

NIL = 0xffffffff
NAME = 1 << 31
ALLOWED = {"propext", "Classical.choice", "Quot.sound"}


def build(folder):
    base = Path(folder)
    if base.name != "sample" and not (base / "unpacked-ok.txt").is_file():
        raise RuntimeError("Require verified unpacked MIT export")
    expr_count, rem = divmod((base / "expr.bin").stat().st_size, 12)
    if rem:
        raise ValueError("Bad expression table length")
    parents = array("I", [0])
    parts = [""]
    stats = collections.Counter()

    def name(i):
        seq = []
        while i:
            seq.append(parts[i])
            i = parents[i]
        return ".".join(reversed(seq))

    def entries(tag, obj):
        if tag == "inductive":
            for d in obj["types"]:
                yield "induct", d, [NAME | i for i in d["ctors"]]
            for d in obj["ctors"]:
                yield "ctor", d, [NAME | d["induct"]]
            for d in obj["recs"]:
                yield "rec", d, [*(NAME | i for i in d["all"]),
                                 *(rule["rhs"] for rule in d["rules"])]
        else:
            yield tag, obj, []

    roots_tmp = base / "roots.tmp"
    db_tmp = base / "symbols.tmp"
    if db_tmp.exists():
        db_tmp.unlink()
    with closing(sqlite3.connect(db_tmp)) as db, roots_tmp.open("wb", buffering=2 << 20) as out:
        db.execute("PRAGMA journal_mode=OFF")
        db.execute("PRAGMA synchronous=OFF")
        db.execute("CREATE TABLE symbol(id INTEGER PRIMARY KEY, name TEXT NOT NULL, tag TEXT NOT NULL, safety TEXT NOT NULL, type_id INTEGER NOT NULL, value_id INTEGER)")
        batch = []
        with (base / "dict.ndjson").open("rb") as rows:
            for line in rows:
                data = json.loads(line)
                tag = next(iter(data))
                if tag == "meta":
                    print(json.dumps(data), flush=True)
                    continue
                if tag == "in":
                    idx = data["in"]
                    item = data["str"] if "str" in data else data["num"]
                    parent = item["pre"]
                    if idx != len(parts) or not 0 <= parent < idx or idx >= NAME:
                        raise ValueError(f"Invalid name sequence: {idx}, prefix {parent}")
                    parents.append(parent)
                    parts.append(item["str"] if "str" in data else str(item["i"]))
                    continue
                if tag not in {"def", "thm", "opaque", "quot", "axiom", "inductive"}:
                    raise ValueError(f"Unknown declaration group {tag}")
                for kind, item, extra in entries(tag, data[tag]):
                    owner = item["name"]
                    typ = item["type"]
                    val = item.get("value", NIL)
                    deps = [typ, val, *extra]
                    if not 0 < owner < len(parts):
                        raise ValueError(f"Unknown declaration name {owner}")
                    for edge in deps:
                        if edge != NIL and not (edge < expr_count if edge < NAME else (edge & ~NAME) < len(parts)):
                            raise ValueError(f"Out-of-range declaration edge: {owner} -> {edge}")
                    out.write(struct.pack(f"<{2+len(deps)}I", owner, len(deps), *deps))
                    safety = item.get("safety", "unsafe" if item.get("isUnsafe") else "")
                    batch.append((owner, name(owner), kind, safety, typ, None if val == NIL else val))
                    stats[kind] += 1
                if len(batch) >= 50_000:
                    db.executemany("INSERT INTO symbol VALUES (?,?,?,?,?,?)", batch)
                    batch.clear()
            db.executemany("INSERT INTO symbol VALUES (?,?,?,?,?,?)", batch)
        db.execute("CREATE INDEX name_lookup ON symbol(name)")
        db.commit()
        if not ALLOWED <= {row[0] for row in db.execute("SELECT name FROM symbol WHERE tag='axiom'")}:
            raise RuntimeError("Export dictionary does not contain the expected three standard axioms")
    roots_tmp.replace(base / "roots.bin")
    db_tmp.replace(base / "symbols.sqlite")
    print(f"{len(parts)-1:,} names, {sum(stats.values()):,} declarations: {dict(stats)}", flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("folder", type=Path)
    build(parser.parse_args().folder)

