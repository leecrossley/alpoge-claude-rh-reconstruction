from pathlib import Path
import csv
import sqlite3
import struct
import argparse
import os
import subprocess

if not __debug__:
    raise SystemExit("This checker requires Python assertions. Run python -E without -O or -OO.")

NIL = 0xffffffff
NAME = 1 << 31
roots = (
    ("riemannHypothesis", "RiemannHypothesis", "rhOfAll", "rhOfAll", 4, 1478219),
    ("riemannZeta_eq_zero_re", "RiemannZetaZerosOnLine", "rhOfAll", "rhOfAll", 6, None),
    ("LFunction_ne_zero_of_half_lt_re", "DirichletLNonvanishingRightOfHalf", "allChi", "allChi", 8, 1478211),
    ("LFunction_eq_zero_re", "DirichletLZerosOnLine", "And.left", "claimAll.2.1", 10, None),
    ("LFunction_eq_zero_re_of_isPrimitive", "PrimitiveDirichletLZerosOnLine", "critAll", "critAll", 12, None),
)
standard = {"Classical.choice", "Quot.sound", "propext"}


def main(full, output, executable):
    out_rows = []
    with sqlite3.connect(full.resolve().joinpath("symbols.sqlite").as_uri()+"?mode=ro",uri=True) as db, \
            (full / "expr.bin").open("rb") as expr:
        tagged = {i:(n,k,s) for i,n,k,s in db.execute(
            "SELECT id,name,tag,safety FROM symbol WHERE tag='axiom' OR safety IN ('partial','unsafe')")}
        expected_application = (((("And.left","Claim.Strip"),"Claim.Zeta"),
           ((("And.right","Claim.HalfPlane"), (("And","Claim.Strip"),"Claim.Zeta")),"claimAll")))
        def tree(i):
            expr.seek(12*i)
            x,y,z=struct.unpack("<III",expr.read(12))
            if z==NIL and y==NIL and NAME <= x < NIL:
                return db.execute("SELECT name FROM symbol WHERE id=?",(x&~NAME,)).fetchone()[0]
            if z==NIL and x<NAME and y<NAME:
                return tree(x),tree(y)
            raise ValueError(f"Not the expected Const/App projection shape: {i}")
        for name, type_name, expected_head, source_value, line, lumi in roots:
            i,tag,t,v=db.execute("SELECT id,tag,type_id,value_id FROM symbol WHERE name=?",(name,)).fetchone()
            assert tag=="thm" and tree(t)==type_name, name
            value=tree(v)
            if name=="LFunction_eq_zero_re":
                assert value==expected_application, value
                pretty="@And.left Claim.Strip Claim.Zeta (@And.right Claim.HalfPlane (And Claim.Strip Claim.Zeta) claimAll)"
                head=expected_head
            else:
                assert value==expected_head
                head=pretty=value
            visited=set()
            axioms=set()
            unsafe=partial=0
            path=full/"walk"/f"{i}.bin"
            if not path.exists():
                path.parent.mkdir(exist_ok=True)
                subprocess.run([str(executable.resolve()), "walk", f"{i}={path.resolve()}"], cwd=full, check=True)
            for x,p,mode in struct.iter_unpack("<IIB",path.read_bytes()):
                if x==p:
                    assert not visited and x==i
                else:
                    assert p in visited and x not in visited and mode in (0,1,2)
                visited.add(x)
                if x in tagged:
                    cname,ckind,safety=tagged[x]
                    if ckind=="axiom": axioms.add(cname)
                    unsafe+=int(safety=="unsafe")
                    partial+=int(safety=="partial")
            assert axioms==standard and not unsafe and not partial,(name,axioms,unsafe,partial)
            count=len(visited)
            assert lumi is None or count==lumi, (name,count,lumi)
            out_rows.append([name,f"lean/src/Main.lean#L{line}",i,type_name,source_value,head,
                             pretty,count,"; ".join(sorted(axioms)),unsafe,partial,
                             "" if lumi is None else lumi,
                             "公开表未列该根" if lumi is None else "精确一致"])
            print(name,count,sorted(axioms),flush=True)
    with output.open("w",encoding="utf8",newline="") as f:
        writer=csv.writer(f,delimiter="\t",lineterminator="\n")
        writer.writerow(["根定理","源码","导出声明ID","正式类型常量","源码值",
                         "编译值头常量","编译值表达式","可达声明数（含根）","可达公理",
                         "unsafe","partial","LUMI计数","LUMI核对"])
        writer.writerows(out_rows)

if __name__=="__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("full", type=Path)
    ap.add_argument("output", type=Path)
    binary = "rhproofgraph.exe" if os.name == "nt" else "rhproofgraph"
    ap.add_argument("--exe", type=Path, default=Path(__file__).parent / "graph" / "target" / "release" / binary)
    args = ap.parse_args()
    main(args.full, args.output, args.exe)

