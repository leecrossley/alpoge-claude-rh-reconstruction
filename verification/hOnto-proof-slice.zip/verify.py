"""Verify the use of hOnto in an archived Lean proof without loading Lean.

Run python verify.py beside proof-slice.ndjson. Optional --export PATH compares
all 544 expression records to the official zstd export (requires zstandard).
Expression IDs and constant names correspond to the pinned MIT export.
"""
import argparse
import bisect
from functools import lru_cache
import hashlib
import json
from pathlib import Path
import re

if not __debug__:
    raise SystemExit("This checker requires Python assertions. Run python -E without -O or -OO.")

base = Path(__file__).parent
rows = {r["ie"]: r for r in map(json.loads, (base / "proof-slice.ndjson").read_text(encoding="utf-8").splitlines())}
ROOT = 398145986
DECL = 5265522
ONTO = 5024717
FAMILY = 5247982
FINISH = 5265521

def term(i):
    return next((k, v) for k, v in rows[i].items() if k != "ie")

def children(i):
    k, t = term(i)
    if k == "app": return [(t["fn"], 0), (t["arg"], 0)]
    if k in ("lam", "forallE"): return [(t["type"], 0), (t["body"], 1)]
    if k == "letE": return [(t["type"], 0), (t["value"], 0), (t["body"], 1)]
    if k == "proj": return [(t["struct"], 0)]
    assert k in ("bvar","sort","const","natVal","strVal")
    return []

def unapply(i):
    args = []
    while True:
        k, t = term(i)
        if k != "app":
            assert k == "const"
            return t["name"], list(reversed(args))
        args.append(t["arg"])
        i = t["fn"]

@lru_cache(maxsize=None)
def uses_binder(i, depth=0):
    k, t = term(i)
    if k == "bvar": return int(t == depth)
    return sum(uses_binder(j, depth + inc) for j, inc in children(i))

def compare_export(path):
    import zstandard
    digest = "61a8938ad5f5e57397c1c0e3b954916af546d9004ade01c3555744a681b05381"
    with path.open("rb") as f:
        assert hashlib.file_digest(f, "sha256").hexdigest() == digest
    needed = sorted(rows)
    seen = set()
    named = set()
    decl_seen = False
    needle = re.compile(b'"ie":([0-9]+)')
    tail = b""
    with path.open("rb") as f, zstandard.ZstdDecompressor(max_window_size=1<<30).stream_reader(f) as zr:
        while not (len(seen) == len(rows) and decl_seen and len(named) == 3):
            block = zr.read(16 << 20)
            if not block: break
            block = tail + block
            end = block.rfind(b"\n") + 1
            block, tail = block[:end], block[end:]
            def record_at(pos):
                return json.loads(block[block.rfind(b"\n", 0, pos) + 1:block.find(b"\n", pos)])
            for i, label in ((848874,"hOnto"),(2390351,"hFam"),(43895,"hS")):
                if i not in named:
                    p = block.find(f'"in":{i},'.encode())
                    if p >= 0:
                        assert record_at(p)["str"] == {"pre":0,"str":label}
                        named.add(i)
            pattern = f'"value":{ROOT}}}}}'.encode()
            p = block.find(pattern)
            if p >= 0 and not decl_seen:
                d = record_at(p)["thm"]
                assert (d["name"],d["type"],d["value"]) == (DECL,398145836,ROOT)
                decl_seen = True
            a, b = block.find(b'"ie":'), block.rfind(b'"ie":')
            if a < 0: continue
            lo, hi = int(needle.match(block, a)[1]), int(needle.match(block, b)[1])
            if bisect.bisect_left(needed,lo) == bisect.bisect_right(needed,hi): continue
            for m in needle.finditer(block):
                i = int(m[1])
                if i in rows:
                    assert i not in seen and record_at(m.start()) == rows[i]
                    seen.add(i)
    assert seen == rows.keys() and decl_seen and len(named) == 3
    print("Compressed export SHA-256, owner declaration, three binder names, and all 544 expression records match.")

ap = argparse.ArgumentParser(description=__doc__); ap.add_argument("--export",type=Path)
opts = ap.parse_args()
if opts.export is not None: compare_export(opts.export)
seen = set()
stack = [ROOT]
while stack:
    i = stack.pop()
    if i not in seen:
        seen.add(i)
        stack.extend(j for j, _ in children(i))
assert len(rows) == 544 and seen == rows.keys()

i = ROOT
while term(i)[0] == "lam": i = term(i)[1]["body"]
assert i == 398145956
k, h_onto = term(i); assert k == "letE" and h_onto["name"] == 848874
k, h_fam = term(h_onto["body"]); assert k == "letE" and h_fam["name"] == 2390351
k, h_s = term(h_fam["body"]); assert k == "letE" and h_s["name"] == 43895
head, _ = unapply(h_onto["value"]); assert head == ONTO
head, args = unapply(h_fam["value"])
assert head == FAMILY and len(args) == 21 and term(args[20]) == ("bvar",0)
assert uses_binder(h_onto["body"]) == 1
head, args = unapply(h_s["body"])
assert head == FINISH and len(args) == 18 and term(args[15]) == ("bvar",1)
assert uses_binder(h_fam["body"]) == 1
print("hOnto is argument 21 of true_geometry_family_row_data_alt.")
print("hFam is argument 16 of mi_star2_of_pu_nz. Both let-bound names occur once in their continuations.")
