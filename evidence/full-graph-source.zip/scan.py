from pathlib import Path
import argparse
import hashlib
import subprocess
import zstandard

PACKED_SIZE = 7699933588
PACKED_SHA = "61a8938ad5f5e57397c1c0e3b954916af546d9004ade01c3555744a681b05381"
UNPACKED_SIZE = 61570595788
UNPACKED_SHA = "5ea74b912147c5c93cc2b6d70cc727cf908df2f62ac6a20480a3fa02f6be244e"


class DigestReader:
    def __init__(self, src):
        self.src = src
        self.digest = hashlib.sha256()
        self.count = 0

    def read(self, n=-1):
        data = self.src.read(n)
        self.digest.update(data)
        self.count += len(data)
        return data


def scan(source, folder, exe, sample):
    folder.mkdir(parents=True, exist_ok=True)
    marker = folder / "unpacked-ok.txt"
    marker.unlink(missing_ok=True)
    count = 0
    digest = hashlib.sha256()
    next_report = 4 << 30
    with source.open("rb") as src:
        packed = DigestReader(src)
        decompressor = zstandard.ZstdDecompressor(max_window_size=1 << 30)
        with decompressor.stream_reader(packed) as stream, subprocess.Popen(
            [str(exe.resolve()), "scan"], cwd=folder, stdin=subprocess.PIPE,
        ) as proc:
            while True:
                data = stream.read(8 << 20)
                if not data:
                    break
                last = sample and count + len(data) >= 20 << 20
                if last:
                    data = data[:data.rfind(b"\n") + 1]
                proc.stdin.write(data)
                count += len(data)
                digest.update(data)
                if count >= next_report:
                    print(f"unpacked {count/(1<<30):.1f} GiB", flush=True)
                    next_report += 4 << 30
                if last:
                    break
            proc.stdin.close()
            if code := proc.wait():
                raise RuntimeError(f"scan process exited {code}")
    hashes = (packed.digest.hexdigest(), digest.hexdigest())
    print(f"packed bytes {packed.count} sha256 {hashes[0]}", flush=True)
    print(f"unpacked bytes {count} sha256 {hashes[1]}", flush=True)
    if not sample:
        if (packed.count, hashes[0]) != (PACKED_SIZE, PACKED_SHA):
            raise RuntimeError("Compressed size or digest differs from MIT")
        if (count, hashes[1]) != (UNPACKED_SIZE, UNPACKED_SHA):
            raise RuntimeError("Decompressed size or digest differs from MIT")
        marker.write_text(
            f"packed {packed.count} {hashes[0]}\nunpacked {count} {hashes[1]}\n",
            encoding="ascii",
        )


if __name__ == "__main__":
    base = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser()
    parser.add_argument("--sample", action="store_true")
    parser.add_argument("--source", type=Path)
    parser.add_argument("--folder", type=Path)
    parser.add_argument("--exe", type=Path, default=base / "graph/target/release/rhproofgraph.exe")
    args = parser.parse_args()
    source = args.source or base / ("prefix.zst" if args.sample else "solution.ndjson.zst")
    folder = args.folder or base / ("sample" if args.sample else "full")
    if not args.sample and not args.source and not (base / "download-ok.txt").is_file():
        parser.error("Wait for verified download")
    scan(source, folder, args.exe, args.sample)

