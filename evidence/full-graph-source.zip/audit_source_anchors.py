"""Resolve line citations conservatively against the pinned source and MIT export."""
import argparse
from bisect import bisect_left
from collections import Counter
import csv
import gzip
from pathlib import Path
import re
import sqlite3

ANCHOR = re.compile(r"\[([^\[\]]+)\]\(<?(\.\./lean/src/[^<>)]+\.lean)#L(\d+)>?\)")
NAME = r"(?:«[^»]+»|[^\W\d]|_)(?:«[^»]+»|[\w'.₀-₉′₂₃⁻⁺]*|(?<=\.)«[^»]+»)*"
DECL = re.compile(r"^(?:(?:private|protected|noncomputable|partial|unsafe|local|scoped|public|nonrec)\s+)*(theorem|lemma|def|abbrev|opaque|structure|class(?:\s+inductive)?|inductive|axiom|coinductive|instance|example)(?:\s+|$)")
ATTR = re.compile(r"^@\[[^\]]+\]\s*")
NAME_TOKEN = re.compile(r"(?:«[^»]+»|[^\s({[:;=])+(?=[\s({[:;=]|$)")
FIELD = re.compile(r"^(?:\|\s+)?(«[^»]+»|[^:\s(){}\[\]]+)\s*(?::|\s+[({\[])")
SCOPE = re.compile(r"^(?:(?:public|meta|noncomputable)\s+)*(namespace|section|mutual)(?:\s+(-?[^\s]+))?\s*$")
BARRIER = re.compile(r"^(?:(?:public|private|local|scoped|noncomputable|meta)\s+)*(?:open|import|export|variable|include|omit|attribute|notation|infix[lr]?|set_option|syntax|macro|elab|universe|universes|initialize|deriving|alias|assert_not_exists|register_option|run_tac|#\w+)(?:\s|$)")
LOCAL = re.compile(r"^(?:(?:have|let|haveI|letI|set|let_fun|obtain|suffices)\s)")
KINDS = {"def":"def","abbrev":"def","theorem":"thm","lemma":"thm",
          "opaque":"opaque","axiom":"axiom","structure":"induct",
          "class":"induct","class inductive":"induct","inductive":"induct",
          "coinductive":"induct","instance":"def","field":"def","ctor":"ctor"}


def code_lines(lines):
    """Mask comments while preserving source line numbers and indentation."""
    nesting = 0
    for line in lines:
        i = 0
        out = []
        quoted = None
        while i < len(line):
            ch = line[i]
            both = line[i:i+2]
            if quoted:
                out.append(ch)
                if ch == "\\" and quoted == '"':
                    i += 1
                    if i < len(line):
                        out.append(line[i])
                elif ch == quoted:
                    quoted = None
            elif both == "/-":
                nesting += 1
                out.append("  ")
                i += 1
            elif nesting and both == "-/":
                nesting -= 1
                out.append("  ")
                i += 1
            elif nesting:
                out.append(" ")
            elif both == "--":
                break
            else:
                if ch in {'"', "«"}:
                    quoted = "»" if ch == "«" else ch
                out.append(ch)
            i += 1
        yield "".join(out).rstrip()


def source_name(raw):
    return ".".join(re.sub(r"^«(.*)»$",r"\1",p) for p in re.findall(r"«[^»]+»|[^.]+",raw))


def candidate(namespace, raw):
    if raw.startswith("_root_."):
        return source_name(raw[7:])
    return ".".join([*namespace, source_name(raw)])


def source_rows(file):
    lines = file.read_text(encoding="utf-8-sig").splitlines()
    scopes = []
    owner = None
    sub = None
    helpers = False
    info = []
    field_indent = None
    structure_body = False
    for n,(raw,clean) in enumerate(zip(lines,code_lines(lines)),1):
        s = clean.strip()
        indent = len(clean)-len(clean.lstrip())
        command = ATTR.sub("",s)
        if not command:
            info.append(("无独立声明",None,None,None,raw,"空行、注释或独立属性"))
            continue
        scope = SCOPE.match(command)
        if scope:
            k, name = scope.groups()
            scopes.append((k, name))
            owner = sub = None
            helpers = False
            info.append(("范围指令",None,None,None,raw,"无独立声明"))
            continue
        end = re.fullmatch(r"end(?:\s+([^\s]+))?", command)
        if end:
            if scopes:
                scopes.pop()
            owner = sub = None
            helpers = False
            info.append(("范围指令",None,None,None,raw,"无独立声明"))
            continue
        d = DECL.match(command)
        if d and (owner is None or indent <= owner[4]):
            kind = " ".join(d.group(1).split())
            rest = command[d.end():].strip()
            tok = NAME_TOKEN.match(rest)
            namespace = [source_name(name) for frame,name in scopes if frame == "namespace" and name]
            name = None
            detail = ""
            if kind != "example" and tok:
                raw_name = tok[0]
                # An anonymous instance starts with its class expression, not a name followed by a colon.
                if kind != "instance" or rest[tok.end():].lstrip().startswith(":"):
                    name = candidate(namespace,raw_name)
            if name is None:
                detail = "匿名示例或实例，没有稳定的源码常量名"
            owner = (name,kind,n,"private" in command[:d.start(1)].split(),indent)
            sub = None
            field_indent = None
            structure_body = " where" in command
            helpers = False
            info.append(("声明头" if name else "匿名命令",owner,None,None,raw,detail))
            continue
        if BARRIER.match(command) and (owner is None or indent <= owner[4]):
            owner = sub = None
            helpers = False
            info.append(("范围或配置指令",None,None,None,raw,"无独立声明"))
            continue
        if owner is None:
            info.append(("未唯一判定",None,None,None,raw,"无法确定活动声明"))
            continue
        if owner[0] is None:
            info.append(("匿名命令内部",owner,None,None,raw,"无独立声明"))
            continue
        # Lean where-helpers may elaborate as lifted or private declarations. Do not give them the owner's name.
        if command == "where" and indent <= owner[4]+2 and owner[1] not in {"structure","class","inductive","class inductive"}:
            helpers = True
            sub = None
        if helpers:
            info.append(("局部 where 辅助声明",owner,None,None,raw,"辅助声明的导出名称未唯一判定"))
            continue
        if command.startswith("where") or command.startswith("| "):
            structure_body = True
        in_fields = structure_body and owner[1] in {"structure","class","inductive","class inductive"}
        if in_fields and indent > owner[4]:
            field = FIELD.match(command)
            if field and (field_indent is None or indent <= field_indent):
                is_ctor=command.startswith("|") or owner[1] in {"inductive","class inductive"}
                role = "ctor" if is_ctor else "field"
                sub = (f"{owner[0]}.{source_name(field[1])}",role,n,owner[3],indent)
                field_indent = indent
                info.append(("构造子" if is_ctor else "结构字段",owner,sub,None,raw,"字段与独立投影分别检查"))
                continue
            if sub and indent > sub[4]:
                info.append(("构造子续行" if sub[1]=="ctor" else "结构字段续行",owner,sub,None,raw,"字段与独立投影分别检查"))
                continue
        if indent <= owner[4] and re.match(r"^[\w#]",command):
            info.append(("未唯一判定",owner,None,None,raw,"与声明头同缩进且非已知命令边界"))
            owner = sub = None
            continue
        if LOCAL.match(command):
            info.append(("局部证明步骤",owner,None,None,raw,"仅追踪外层声明，不把局部绑定当独立常量"))
        else:
            info.append(("声明内部",owner,None,None,raw,"仅证明拥有者可达，不证明此行必要"))
    return info


def cells(db, node, module, depths):
    if not node or not node[0]:
        return "", "", "未唯一判定", "", ""
    name,kind,line,private,_ = node
    kindcheck = KINDS.get(kind)
    if private:
        prefix = f"_private.{module}."
        escaped = prefix.replace("\\","\\\\").replace("_","\\_").replace("%","\\%")
        rows = db.execute("SELECT id,name,tag FROM symbol WHERE name LIKE ? ESCAPE '\\' AND substr(name,length(name)-length(?)+1)=?",
                          (escaped+"%", "."+name, "."+name)).fetchall()
        rows = [r for r in rows if r[1].startswith(prefix) and re.fullmatch(r"\d+\."+re.escape(name),r[1][len(prefix):])]
    else:
        rows = db.execute("SELECT id,name,tag FROM symbol WHERE name=?",(name,)).fetchall()
    if len(rows) > 1:
        return name, line, "未唯一判定", "", ""
    if not rows:
        return name, line, "导出未收录", "", ""
    ident, full, tag = rows[0]
    if kindcheck and tag!=kindcheck and not ((kind=="instance" and tag in {"thm","opaque"}) or (kind=="field" and tag=="thm")):
        return name,line,"未唯一判定","",""
    if ident in depths:
        return full,line,"根可达",ident,depths[ident]
    return full,line,"已导出，根不可达",ident,""


def audit(paper, symbols):
    evidence=paper/"证据"
    depths={}
    with gzip.open(evidence/"rh-dependency-tree.tsv.gz","rt",encoding="utf8",newline="") as f:
        for row in csv.DictReader(f,delimiter="\t"):
            depths[int(row["id"])]=int(row["depth"])
    runs={}
    counts=Counter()
    with sqlite3.connect(symbols.resolve().as_uri()+"?mode=ro",uri=True) as db, \
         (evidence/"源码引用与证明项.tsv").open("w",encoding="utf8",newline="") as f:
        out=csv.writer(f,delimiter="\t",lineterminator="\n")
        out.writerow(["章节","讲义行号","段标题","引文","源码路径","锚点行","锚点角色",
                      "拥有声明","声明行","拥有声明状态","拥有声明ID","拥有声明深度",
                      "字段或构造子常量","成员行","成员常量状态","成员ID","成员深度","锚点源码","说明"])
        for chapter in sorted(paper.glob("[0-9]*.md")):
            heading=""
            for paper_line,line in enumerate(chapter.read_text(encoding="utf-8-sig").splitlines(),1):
                if line.startswith("#"):
                    heading=line.lstrip("# ")
                for label,source,n in ANCHOR.findall(line):
                    file=(paper/source).resolve()
                    path=source.removeprefix("../lean/src/")
                    if file not in runs:
                        runs[file]=source_rows(file)
                    n=int(n)
                    if not 1 <= n <= len(runs[file]):
                        raise ValueError((file,n))
                    role, owner, sub, _, raw, detail=runs[file][n-1]
                    module=path.removesuffix(".lean").replace("/",".")
                    owner_data=cells(db,owner,module,depths) if owner is not None else ("","","不适用","","")
                    if role=="未唯一判定":
                        owner_data=("", "", "未唯一判定", "", "")
                    member_data=cells(db,sub,module,depths) if sub else ("","","不适用","","")
                    if sub:
                        detail+="；Expr.proj 不把投影常量计作显式引用"
                    counts[(role,owner_data[2])]+=1
                    out.writerow((chapter.name,paper_line,heading,label,"lean/src/"+path,n,role,
                                  *owner_data,*member_data,raw.strip(),detail))
    for (role,status), count in counts.most_common():
        print(f"{role}\t{status}\t{count}")
    print("Total",sum(counts.values()))


if __name__=="__main__":
    p=argparse.ArgumentParser()
    p.add_argument("paper",type=Path)
    p.add_argument("symbols",type=Path)
    a=p.parse_args()
    audit(a.paper,a.symbols)

